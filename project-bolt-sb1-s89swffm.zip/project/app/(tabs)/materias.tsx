import { useState, useEffect } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  TextInput,
  Modal,
  Alert,
} from 'react-native';
import { Pencil, Plus, ChevronDown } from 'lucide-react-native';
import { supabase } from '@/lib/supabase';

interface Subject {
  id: string;
  name: string;
  professor: string;
  accumulated_points: number;
  current_grade: number;
  color: string;
}

export default function MateriasScreen() {
  const [subjects, setSubjects] = useState<Subject[]>([]);
  const [loading, setLoading] = useState(true);
  const [modalVisible, setModalVisible] = useState(false);
  const [editMode, setEditMode] = useState(false);
  const [currentSubject, setCurrentSubject] = useState<Subject | null>(null);
  const [formData, setFormData] = useState({
    name: '',
    professor: '',
    accumulated_points: '',
    current_grade: '',
  });
  const [minPassingGrade, setMinPassingGrade] = useState<number>(10);

  useEffect(() => {
    loadSubjects();
  }, []);

  const loadSubjects = async () => {
    try {
      const {
        data: { user },
      } = await supabase.auth.getUser();
      if (!user) return;

      const { data: settingsData } = await supabase
        .from('settings')
        .select('*')
        .eq('user_id', user.id)
        .maybeSingle();

      if (settingsData) {
        setMinPassingGrade(settingsData.min_passing_grade);
      }

      const { data } = await supabase
        .from('subjects')
        .select('*')
        .eq('user_id', user.id)
        .order('name', { ascending: true });

      if (data) {
        setSubjects(data);
      }
    } catch (error) {
      console.error('Error loading subjects:', error);
    } finally {
      setLoading(false);
    }
  };

  const getSubjectColor = (grade: number) => {
    if (grade >= minPassingGrade + 3) return '#84cc16';
    if (grade >= minPassingGrade) return '#22d3ee';
    if (grade >= minPassingGrade - 3) return '#a855f7';
    return '#f97316';
  };

  const getIndicatorColor = (grade: number) => {
    if (grade >= minPassingGrade + 3) return '#22c55e';
    if (grade >= minPassingGrade) return '#eab308';
    return '#ef4444';
  };

  const openAddModal = () => {
    setEditMode(false);
    setCurrentSubject(null);
    setFormData({
      name: '',
      professor: '',
      accumulated_points: '',
      current_grade: '',
    });
    setModalVisible(true);
  };

  const openEditModal = (subject: Subject) => {
    setEditMode(true);
    setCurrentSubject(subject);
    setFormData({
      name: subject.name,
      professor: subject.professor,
      accumulated_points: subject.accumulated_points.toString(),
      current_grade: subject.current_grade.toString(),
    });
    setModalVisible(true);
  };

  const handleSave = async () => {
    if (!formData.name.trim()) {
      Alert.alert('Error', 'El nombre de la materia es requerido');
      return;
    }

    try {
      const {
        data: { user },
      } = await supabase.auth.getUser();
      if (!user) return;

      const { data: periodData } = await supabase
        .from('academic_period')
        .select('*')
        .eq('user_id', user.id)
        .eq('is_active', true)
        .maybeSingle();

      let periodId = periodData?.id;

      if (!periodId) {
        const { data: newPeriod } = await supabase
          .from('academic_period')
          .insert({
            user_id: user.id,
            name: 'Primer Lapso',
            is_active: true,
          })
          .select()
          .single();
        periodId = newPeriod?.id;
      }

      const grade = parseFloat(formData.current_grade) || 0;
      const color = getSubjectColor(grade);

      const subjectData = {
        name: formData.name,
        professor: formData.professor,
        accumulated_points: parseFloat(formData.accumulated_points) || 0,
        current_grade: grade,
        color: color,
        user_id: user.id,
        period_id: periodId,
      };

      if (editMode && currentSubject) {
        await supabase
          .from('subjects')
          .update(subjectData)
          .eq('id', currentSubject.id);
      } else {
        await supabase.from('subjects').insert(subjectData);
      }

      setModalVisible(false);
      loadSubjects();
    } catch (error) {
      console.error('Error saving subject:', error);
      Alert.alert('Error', 'No se pudo guardar la materia');
    }
  };

  return (
    <View style={styles.container}>
      <ScrollView
        style={styles.scrollView}
        contentContainerStyle={styles.scrollContent}>
        <View style={styles.header}>
          <Text style={styles.headerTitle}>materias</Text>
        </View>

        <View style={styles.content}>
          <Text style={styles.description}>
            gestiona tus materias y sus notas especificas
          </Text>
          <View style={styles.divider} />

          <View style={styles.filterRow}>
            <TouchableOpacity style={styles.filterButton}>
              <Text style={styles.filterText}>todas las materias</Text>
              <ChevronDown size={20} color="#0f172a" strokeWidth={2} />
            </TouchableOpacity>
            <TouchableOpacity
              style={styles.addButton}
              onPress={openAddModal}>
              <Plus size={24} color="#0f172a" strokeWidth={2} />
            </TouchableOpacity>
          </View>

          <View style={styles.subjectsList}>
            {subjects.map((subject) => (
              <View
                key={subject.id}
                style={[
                  styles.subjectCard,
                  { borderColor: subject.color, borderWidth: 3 },
                ]}>
                <View style={styles.subjectHeader}>
                  <Text style={styles.subjectName}>{subject.name}</Text>
                  <TouchableOpacity
                    onPress={() => openEditModal(subject)}
                    style={styles.editButton}>
                    <Pencil size={20} color="#0f172a" strokeWidth={2} />
                  </TouchableOpacity>
                </View>
                <View style={styles.subjectInfo}>
                  <View style={styles.subjectDetails}>
                    <Text style={styles.professorLabel}>profesor</Text>
                    <Text style={styles.professorName}>
                      {subject.professor || 'Sin asignar'}
                    </Text>
                    <Text style={styles.pointsLabel}>
                      puntos acumulados{' '}
                      {subject.accumulated_points.toFixed(1)}
                    </Text>
                  </View>
                  <View style={styles.gradeCircle}>
                    <Text style={styles.gradeValue}>
                      {subject.current_grade.toFixed(1)}
                    </Text>
                  </View>
                </View>
                <TouchableOpacity style={styles.evaluationsButton}>
                  <Text style={styles.evaluationsText}>evaluaciones</Text>
                  <View
                    style={[
                      styles.statusIndicator,
                      {
                        backgroundColor: getIndicatorColor(
                          subject.current_grade
                        ),
                      },
                    ]}
                  />
                </TouchableOpacity>
              </View>
            ))}
          </View>
        </View>
      </ScrollView>

      <Modal
        visible={modalVisible}
        animationType="slide"
        transparent={true}
        onRequestClose={() => setModalVisible(false)}>
        <View style={styles.modalOverlay}>
          <View style={styles.modalContent}>
            <Text style={styles.modalTitle}>
              {editMode ? 'Editar Materia' : 'Nueva Materia'}
            </Text>

            <TextInput
              style={styles.input}
              placeholder="Nombre de la materia"
              placeholderTextColor="#64748b"
              value={formData.name}
              onChangeText={(text) =>
                setFormData({ ...formData, name: text })
              }
            />

            <TextInput
              style={styles.input}
              placeholder="Profesor"
              placeholderTextColor="#64748b"
              value={formData.professor}
              onChangeText={(text) =>
                setFormData({ ...formData, professor: text })
              }
            />

            <TextInput
              style={styles.input}
              placeholder="Puntos acumulados"
              placeholderTextColor="#64748b"
              keyboardType="numeric"
              value={formData.accumulated_points}
              onChangeText={(text) =>
                setFormData({ ...formData, accumulated_points: text })
              }
            />

            <TextInput
              style={styles.input}
              placeholder="Nota actual"
              placeholderTextColor="#64748b"
              keyboardType="numeric"
              value={formData.current_grade}
              onChangeText={(text) =>
                setFormData({ ...formData, current_grade: text })
              }
            />

            <View style={styles.modalButtons}>
              <TouchableOpacity
                style={[styles.modalButton, styles.cancelButton]}
                onPress={() => setModalVisible(false)}>
                <Text style={styles.cancelButtonText}>Cancelar</Text>
              </TouchableOpacity>
              <TouchableOpacity
                style={[styles.modalButton, styles.saveButton]}
                onPress={handleSave}>
                <Text style={styles.saveButtonText}>Guardar</Text>
              </TouchableOpacity>
            </View>
          </View>
        </View>
      </Modal>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#1e293b',
  },
  scrollView: {
    flex: 1,
  },
  scrollContent: {
    paddingBottom: 100,
  },
  header: {
    backgroundColor: '#a855f7',
    marginHorizontal: 16,
    marginTop: 60,
    marginBottom: 20,
    paddingVertical: 20,
    borderRadius: 20,
    alignItems: 'center',
  },
  headerTitle: {
    fontSize: 28,
    fontWeight: 'bold',
    color: '#ffffff',
  },
  content: {
    paddingHorizontal: 16,
  },
  description: {
    fontSize: 14,
    color: '#ffffff',
    marginBottom: 12,
  },
  divider: {
    height: 2,
    backgroundColor: '#ffffff',
    marginBottom: 24,
  },
  filterRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 24,
    gap: 12,
  },
  filterButton: {
    flex: 1,
    backgroundColor: '#e2e8f0',
    borderRadius: 20,
    paddingVertical: 12,
    paddingHorizontal: 16,
    flexDirection: 'row',
    justifyContent: 'center',
    alignItems: 'center',
    gap: 8,
  },
  filterText: {
    fontSize: 16,
    fontWeight: '600',
    color: '#0f172a',
  },
  addButton: {
    backgroundColor: '#e2e8f0',
    width: 50,
    height: 50,
    borderRadius: 25,
    justifyContent: 'center',
    alignItems: 'center',
  },
  subjectsList: {
    gap: 16,
  },
  subjectCard: {
    backgroundColor: '#bfdbfe',
    borderRadius: 20,
    padding: 16,
  },
  subjectHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 12,
  },
  subjectName: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#0f172a',
    flex: 1,
  },
  editButton: {
    padding: 4,
  },
  subjectInfo: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 12,
  },
  subjectDetails: {
    flex: 1,
  },
  professorLabel: {
    fontSize: 14,
    fontWeight: '600',
    color: '#0f172a',
  },
  professorName: {
    fontSize: 16,
    color: '#0f172a',
    marginBottom: 4,
  },
  pointsLabel: {
    fontSize: 14,
    color: '#0f172a',
  },
  gradeCircle: {
    width: 70,
    height: 70,
    borderRadius: 35,
    backgroundColor: '#ffffff',
    borderWidth: 3,
    borderColor: '#0f172a',
    justifyContent: 'center',
    alignItems: 'center',
  },
  gradeValue: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#0f172a',
  },
  evaluationsButton: {
    backgroundColor: '#ffffff',
    borderRadius: 20,
    paddingVertical: 10,
    paddingHorizontal: 16,
    flexDirection: 'row',
    justifyContent: 'center',
    alignItems: 'center',
    gap: 8,
  },
  evaluationsText: {
    fontSize: 16,
    fontWeight: '600',
    color: '#0f172a',
  },
  statusIndicator: {
    width: 16,
    height: 16,
    borderRadius: 8,
  },
  modalOverlay: {
    flex: 1,
    backgroundColor: 'rgba(0, 0, 0, 0.5)',
    justifyContent: 'center',
    alignItems: 'center',
    padding: 20,
  },
  modalContent: {
    backgroundColor: '#e2e8f0',
    borderRadius: 20,
    padding: 24,
    width: '100%',
    maxWidth: 400,
  },
  modalTitle: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#0f172a',
    marginBottom: 20,
    textAlign: 'center',
  },
  input: {
    backgroundColor: '#ffffff',
    borderRadius: 12,
    paddingVertical: 12,
    paddingHorizontal: 16,
    fontSize: 16,
    color: '#0f172a',
    marginBottom: 12,
    borderWidth: 1,
    borderColor: '#cbd5e1',
  },
  modalButtons: {
    flexDirection: 'row',
    gap: 12,
    marginTop: 8,
  },
  modalButton: {
    flex: 1,
    paddingVertical: 14,
    borderRadius: 12,
    alignItems: 'center',
  },
  cancelButton: {
    backgroundColor: '#64748b',
  },
  saveButton: {
    backgroundColor: '#a855f7',
  },
  cancelButtonText: {
    color: '#ffffff',
    fontSize: 16,
    fontWeight: '600',
  },
  saveButtonText: {
    color: '#ffffff',
    fontSize: 16,
    fontWeight: '600',
  },
});
